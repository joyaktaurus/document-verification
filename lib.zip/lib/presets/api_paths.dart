abstract class ApiPaths {
  static const baseUrl = 'https://demo.dm.instio.co/holidayInn/';
  static const imagePath = 'https://demo.dm.instio.co/holidayInn/document/images';
  static const verification = 'document/verification';
  static const uploadimage = 'https://demo.dm.instio.co/holidayInn/document/images';
}
