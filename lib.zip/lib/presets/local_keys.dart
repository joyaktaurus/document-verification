abstract class LocalKeys {
  static const token = "token";
}
