abstract class App {
  static const String appTitle = "Doc Verifier";
  static const String appVersionName = "1.0.0";
  static String token = '';
  static String appCurrency = '\u0024';
}
